﻿using ConsoleApp3.classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var account = new BankAccount("<name>", 1000);
            Console.WriteLine($"Account{account.Number} was created for {account.Owner} with {account.Balance} initial balance.");
            Console.WriteLine(account.Balance);
            account.MakeDeposit(100, DateTime.Now, "friend paid me back");
            Console.WriteLine(account.Balance);
            Console.WriteLine(account.GetAccountHistory);

            BankAccount invalidAccount;
            try
            {
                invalidAccount = new BankAccount("invalid", -55);
            }
            catch(ArgumentOutOfRangeException e)
            {
                Console.WriteLine("Exceptin caught creating account with negative balance");
                Console.WriteLine(e.ToString());
                return;
            }
            Console.WriteLine(account.GetAccountHistory());
            try
            {
                account.MakeWithdrawal(750, DateTime.Now, "Attempt to overdraw");
            }
            catch(InvalidOperationException e)
            {
                Console.WriteLine("Exceptin caught trying to overdraw");
                Console.WriteLine(e.ToString());
            }
        }
    }
}
