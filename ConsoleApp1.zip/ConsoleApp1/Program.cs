﻿//8. Вычислить площадь круга радиуса R. Максимально задействовать 
//имеющиеся в распоряжении функции модуля «Математика».
//Головачёва Полина 22ис-21

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
                double r = Convert.ToDouble(Console.ReadLine());
                double S;
                double pi = 3.14;
                S = pi * Math.Pow(r, 2);
                Console.WriteLine(S);
            
        }
    }
}
