﻿//Вариант №8
//Вводится кириллический символ. В ответ указывается наименование кириллического 
//символа, назначенного на клавишу клавиатуры, расположенную справа сверху от этого 
//символа (если таковой существует).

//Головачёва Полина 22ис-21

using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите кириллический символ: ");
        char input = char.Parse(Console.ReadLine()); // вводим кириллический символ

        string[] keyboardLayout = new string[]
        {
            "1234567890-=",
            "йцукенгшщзхъ",
            "фывапролджэ",
            "ячсмитьбю.",
        };

        int row = -1;
        int column = -1;

        // ищем символ в раскладке клавиатуры
        for (int i = 0; i < keyboardLayout.Length; i++)
        {
            int j = keyboardLayout[i].IndexOf(input);
            if (j != -1)
            {
                row = i;
                column = j;
                break;
            }
        }

        if (row == -1 || column == -1)
        {
            Console.WriteLine("Символ не найден в раскладке клавиатуры.");
        }
        else
        {
            char rightSymbol = '\0';

            // проверяем, есть ли символ справа сверху
            if (column < keyboardLayout[row].Length - 1 && row > 0 && keyboardLayout[row - 1].Length > column + 1)
            {
                rightSymbol = keyboardLayout[row - 1][column + 1];
            }

            if (rightSymbol != '\0')
            {
                Console.WriteLine("Правый верхний символ: " + rightSymbol);
            }
            else
            {
                Console.WriteLine("Правый верхний символ отсутствует.");
            }
        }
    }
}
