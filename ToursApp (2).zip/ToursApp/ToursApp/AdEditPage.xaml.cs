﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ToursApp
{
    /// <summary>
    /// Логика взаимодействия для AdEditPage.xaml
    /// </summary>
    public partial class AdEditPage : Page
    {
        private Hotel _currentHotel = new Hotel(); 

        public AdEditPage()
        {
            InitializeComponent();
            DataContext = _currentHotel;
            ComboCountries.ItemsSource = ToursEntities.GetContext().Country.ToList();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors= new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentHotel.Name))
                errors.AppendLine("Put hotel name");
            if(_currentHotel.CountOfStars < 1 || _currentHotel.CountOfStars >5)
                errors.AppendLine("Number of stars - number from 1 to 5");
            if (_currentHotel.Country == null)
                errors.AppendLine("Choose country");

            if(errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if(_currentHotel.Id == 0)
                ToursEntities.GetContext().Hotel.Add(_currentHotel));
            try
            {
                ToursEntities.GetContext().SaveChanges();
                MessageBox.Show("Information saved");
                Manager.MainFrame.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
