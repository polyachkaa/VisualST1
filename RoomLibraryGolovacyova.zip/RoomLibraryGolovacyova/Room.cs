﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoomLibraryGolovacyova
{
    public class Room
    {
        double roomLength;
        double roomWidth;

        public double RoomLenght
        {
            get { return roomLength; }
            set { roomLength = value; }
        }
        /// <summary>
        /// Метод вычисляет периметр комнаты
        /// </summary>
        /// <returns> Возвращает значене периметра </returns>
        public double RoomWidth
        {
            get { return roomWidth; }
            set { roomWidth = value; }
        }
        public double RoomPerimeter()
        {
            return 2 * (roomLength + roomWidth);
        }

        public double RoomArea()
        {
            return roomLength * roomWidth;
        }
        /// <summary>
        /// Метов вычисляет число квадратных метров на одного человека
        /// </summary>
        /// <param name="np"></param>
        /// <returns> Возвращает число квадратных метров </returns>
        public double PersonArea(int np)
        {
            return RoomArea() / np; 
        }

    }
}

