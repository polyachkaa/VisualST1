﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MapGolovachyova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void clear()
        {
            throw new NotImplementedException();
        }


        private void pictureBox2_Click(object sender, EventArgs e)
        {
            clear();
            panel1.Text = "Race Start 1";
            panel1.Text = "Samba full marathon";
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            clear();
            panel1.Text = "Race Start 2";
            panel1.Text = "Jongo Half marathon";
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            clear();
            panel1.Text = "Race Start 3";
            panel1.Text = "Capoiera Fun Run Skm";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            panel1.Text = "Finish!";
        }
    }
}
