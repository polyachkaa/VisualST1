﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MapGolovachyova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void clear()
        {
            pictureBoxDrinks.Visible = false; labelDrinks.Visible = false;
            pictureBoxEnergy.Visible = false; labelEnergy.Visible = false;
            pictureBoxToilets.Visible = false; labelToilets.Visible = false;
            pictureBoxInformation.Visible = false; labelInformation.Visible = false;
            pictureBoxMedical.Visible = false; labelMedical.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
      


        private void pictureBox2_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Elektrozavodskaya";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxToilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Aviamotornaya";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxToilets.Visible = true; labelToilets.Visible = true;
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Nizhegorodskaya";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxToilets.Visible = true; labelToilets.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Tekstilschiki";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxToilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Nagatinskiy Zaton";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxToilets.Visible = true; labelToilets.Visible = true;
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Klenovy Bulvar";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxToilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Novatorskaya";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxToilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Start race 2";
            MapLabel.Text = "Jongo halfmarathon";
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Start race 3";
            MapLabel.Text = "Kapoeira funny 5 km race";
        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            NameLabel.Text = "Finish!";
        }

        private void pictureBox4_Click_1(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Sokolniki";
            pictureBoxEnergy.Visible = true; labelDrinks.Visible = true;
            pictureBoxDrinks.Visible = true; labelEnergy.Visible = true;
        }

        private void pictureBox3_Click_1(object sender, EventArgs e)
        {
            clear();
            NameLabel.Text = "Start race 1";
            MapLabel.Text = "Sambo full marathon";
        }
    }
    }
    

